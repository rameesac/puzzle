import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PuzzleViewComponent } from './puzzle-view/puzzle-view.component';
import { QuestionModalComponent } from './puzzle-view/question-modal/question-modal.component';
import { OverviewComponent } from './overview/overview.component';

import { CountdownModule } from 'ngx-countdown';
import { ReactiveFormsModule } from '@angular/forms';
import { LandingComponent } from './landing/landing.component';

@NgModule({
  declarations: [
    AppComponent,
    PuzzleViewComponent,
    QuestionModalComponent,
    OverviewComponent,
    LandingComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    CountdownModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
