import { Component, OnDestroy } from '@angular/core';
import contentJson from '../assets/json/content.json';

@Component({
  selector: 'who-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnDestroy {
  title = contentJson.title;

  ngOnDestroy(): void {
    window.sessionStorage.clear();
  }
}
