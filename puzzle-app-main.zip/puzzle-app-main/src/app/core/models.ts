export interface ContentModel {
  title?: string;
  blocks?: BlockModel[];
}

export interface BlockModel {
  title?: string;
  value?: number;
  name?: string;
  abc?: number;
  block_image?: string;
  questions?: QuestionModel[];
}

export interface QuestionModel {
  serial_no?: number;
  isGridOpen?: boolean;
  isAnswerCorrect?: boolean;
  question?: string;
  answers?: AnswerModel[];
  correct_answer?: number;
}

export interface AnswerModel {
  serial_no?: number;
  answer?: string;
}

export interface ConfigModel {
  overview: OverviewConfigModel;
  puzzles: OverviewConfigModel;
  points: PointsModel;
}

export interface OverviewConfigModel {
  isShuffled: boolean;
 }

export interface PointsModel {
  inital: number;
  split: number;
  minus: number;
  bonus: number;
}
