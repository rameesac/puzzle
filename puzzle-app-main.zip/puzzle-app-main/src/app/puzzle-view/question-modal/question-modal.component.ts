import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { QuestionModel } from './../../core/models';

@Component({
  selector: 'who-question-modal',
  templateUrl: './question-modal.component.html',
  styleUrls: ['./question-modal.component.scss'],
})
export class QuestionModalComponent implements OnInit {
  @Input()
  questions: QuestionModel;

  @Output()
  closeModal: EventEmitter<boolean> = new EventEmitter<boolean>();

  answerForm: FormGroup;

  constructor(fb: FormBuilder) {
    this.answerForm = fb.group({
      answer: ['', Validators.required],
    });
  }

  ngOnInit(): void {
    this.questions.answers.map((el, index) => {
      el.serial_no = index + 1;
    });

    console.log('--------', this.questions.answers);


  }

  answer(): void {
    this.questions.isGridOpen = true;
    if (this.answerForm.valid) {
      this.questions.isAnswerCorrect =
        Number(this.answerForm.get('answer').value) ===
        this.questions.correct_answer
          ? true
          : false;
    }
    this.closeModal.emit(this.questions.isAnswerCorrect);
  }
}
