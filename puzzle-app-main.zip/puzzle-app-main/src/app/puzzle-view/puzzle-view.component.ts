import { Component, OnDestroy } from '@angular/core';
import {
  BlockModel,
  ConfigModel,
  PointsModel,
  QuestionModel,
} from './../core/models';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';

import contentJson from '../../assets/json/content.json';
import configJson from '../../assets/json/config.json';

const CONFIG: ConfigModel = configJson;
const POINTS: PointsModel = configJson.points;

@Component({
  selector: 'who-puzzle-view',
  templateUrl: './puzzle-view.component.html',
  styleUrls: ['./puzzle-view.component.scss'],
})
export class PuzzleViewComponent implements OnDestroy {
  block: BlockModel;
  activeBlock: number;
  paramSubscribe: Subscription;
  openModal: boolean;
  selectedGrid: QuestionModel;
  totalPoint: number;
  guessComplete: boolean;
  puzzleBlocks: QuestionModel[];

  constructor(private router: ActivatedRoute) {
    this.paramSubscribe = this.router.params.subscribe((el) => {
      this.activeBlock = el.block ? el.block : 1;
    });

    this.block = contentJson.blocks.filter(
      (el) => el.value === Number(this.activeBlock)
    )[0];

    this.block.questions.map((el, index) => {
      el.serial_no = index + 1;
      el.isGridOpen = false;
      el.isAnswerCorrect = false;
    });

    this.puzzleBlocks = CONFIG.overview.isShuffled
      ? this.shuffle(this.block.questions)
      : this.block.questions;
    this.reset();
  }

  shuffle(array: QuestionModel[]): QuestionModel[] {
    return array.sort(() => Math.random() - 0.5);
  }

  reset(): void {
    this.totalPoint = POINTS.inital;
    this.guessComplete = false;
    this.openModal = false;
  }

  openPuzzleBlock(block: QuestionModel): void {
    this.selectedGrid = block;
    if (!block.isGridOpen) {
      this.openModal = true;
    }
  }

  wrongGuess(): void {
    this.totalPoint = !this.guessComplete
      ? (this.totalPoint -= POINTS.minus)
      : this.totalPoint;
  }

  reloadGrid(): void {
    this.block.questions.map((el) => {
      el.isGridOpen = false;
      el.isAnswerCorrect = false;
    });
    this.reset();
  }

  closeModal(status: boolean): void {
    this.totalPoint = status ? this.totalPoint + POINTS.split : this.totalPoint;
    this.openModal = false;
  }

  complete(): void {
    if (
      this.block.questions.filter((el) => el.isGridOpen && el.isAnswerCorrect)
        .length > 0
    ) {
      this.block.questions.map((el) => {
        if (!el.isGridOpen) {
          this.totalPoint += POINTS.bonus;
          el.isGridOpen = true;
        }
        el.isAnswerCorrect = true;
      });

      this.guessComplete = true;
      window.sessionStorage.setItem(this.block.value.toString(), 'opened');
    }
  }

  ngOnDestroy(): void {
    if (this.paramSubscribe) {
      this.paramSubscribe.unsubscribe();
    }
  }
}
