import { Component, OnInit } from '@angular/core';
import { BlockModel, ConfigModel } from '../core/models';
import { Router } from '@angular/router';

import contentJson from '../../assets/json/content.json';
import configJson from '../../assets/json/config.json';

const CONFIG: ConfigModel = configJson;

@Component({
  selector: 'who-overview',
  templateUrl: './overview.component.html',
  styleUrls: ['./overview.component.scss'],
})
export class OverviewComponent implements OnInit {
  content: BlockModel[];
  shuffledContent: BlockModel[];

  constructor(private router: Router) {
    this.content = contentJson.blocks;
    this.content.map((el, index) => {
      el.title = index === 0 ? 'A' : (index + 1).toString();
    });

    this.shuffledContent = CONFIG.puzzles.isShuffled
      ? this.shuffle(this.content)
      : this.content;
  }

  ngOnInit(): void {
    this.content = this.content.filter((el) =>
      window.sessionStorage.getItem(el.value.toString()) ? false : true
    );
  }

  shuffle(array: BlockModel[]): BlockModel[] {
    return array.sort(() => Math.random() - 0.5);
  }

  blockSelected(selected: BlockModel): void {
    if (window.sessionStorage.getItem(selected.value.toString()) !== 'opened') {
      this.router.navigate(['/puzzle-view', selected.value]);
    }
  }

  goBack(): void {
    this.router.navigate(['/']);
  }
}
