import { BehaviorSubject, Subscription } from 'rxjs';
import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'who-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.scss'],
})
export class LandingComponent {
  loaunchApp: boolean;

  constructor(private router: Router) {
    this.loaunchApp = false;

    setTimeout(() => {
      this.loaunchApp = true;
    }, 3000);
  }

  playNow(): void {
    this.router.navigate(['/overview']);
  }
}
